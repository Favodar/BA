from ._GetObjectInformation import *
